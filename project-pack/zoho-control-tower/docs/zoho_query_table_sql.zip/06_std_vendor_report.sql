-- Query Table: STD_Vendor_Report
-- Purpose: Standardize vendor master data.
-- Source: RAW_Vendor_Report
-- Join keys downstream: vendor_name, vendor_code.

SELECT
    v."row_id" AS "vendor_row_id",
    v."vendor_name",
    v."vendor_code",
    v."description",
    v."contact_person",
    v."contact_number",
    v."email",
    v."tin_number",
    v."service_tax_number",
    v."gstin_number",
    v."msme",
    v."fssai_number",
    v."pan_number",
    CAST(v."from_date" AS DATE) AS "from_date",
    CAST(v."to_date" AS DATE) AS "to_date",
    v."state",
    v."address"
FROM "RAW_Vendor_Report" v;
