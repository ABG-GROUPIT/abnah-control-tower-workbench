-- Query Table: STD_Sales_Report
-- Purpose: Union outlet-specific RAW sales feeds into a stable daily outlet-item sales grain.
-- Sources: RAW_Sales_Report_OUT001, RAW_Sales_Report_OUT002, RAW_Sales_Report_OUT003
-- Needs Zoho syntax validation: CAST behavior may vary if Zoho already imports dates/numbers correctly.

SELECT
    src."row_id" AS "sales_row_id",
    src."outlet_name",
    CASE
        WHEN src."outlet_name" = 'ABNAH Cafe Connaught Place' THEN 'OUT001'
        WHEN src."outlet_name" = 'ABNAH Cafe Hauz Khas' THEN 'OUT002'
        WHEN src."outlet_name" = 'ABNAH Cafe Saket Premium' THEN 'OUT003'
        ELSE NULL
    END AS "outlet_code",
    CASE
        WHEN src."outlet_name" = 'ABNAH Cafe Connaught Place' THEN 'Connaught Place'
        WHEN src."outlet_name" = 'ABNAH Cafe Hauz Khas' THEN 'Hauz Khas'
        WHEN src."outlet_name" = 'ABNAH Cafe Saket Premium' THEN 'Saket'
        ELSE NULL
    END AS "market_area",
    CAST(src."date" AS DATE) AS "sales_date",
    src."super_category",
    src."category",
    src."item_number",
    src."item_name",
    CAST(src."qty" AS DECIMAL(12,4)) AS "qty",
    CAST(src."net_sale" AS DECIMAL(14,2)) AS "net_sale",
    CASE
        WHEN CAST(src."qty" AS DECIMAL(12,4)) <> 0
        THEN CAST(src."net_sale" AS DECIMAL(14,2)) / CAST(src."qty" AS DECIMAL(12,4))
        ELSE NULL
    END AS "net_sale_per_qty"
FROM (
    SELECT * FROM "RAW_Sales_Report_OUT001"
    UNION ALL
    SELECT * FROM "RAW_Sales_Report_OUT002"
    UNION ALL
    SELECT * FROM "RAW_Sales_Report_OUT003"
) src;
