-- Query Table: DIM_Menu_Item
-- Purpose: Reusable menu item dimension from menu master plus any sold items not found in the master.
-- Sources: STD_Menu_Master, STD_Sales_Report
-- Join keys: item_number, item_name.

SELECT
    m."item_number" AS "menu_item_key",
    m."item_number",
    m."item_name",
    m."menu_rate",
    m."category_name",
    m."super_category_name",
    m."non_veg",
    m."has_variant",
    'Menu Master' AS "source_type"
FROM "STD_Menu_Master" m

UNION

SELECT
    s."item_number" AS "menu_item_key",
    s."item_number",
    s."item_name",
    NULL AS "menu_rate",
    MAX(s."category") AS "category_name",
    MAX(s."super_category") AS "super_category_name",
    NULL AS "non_veg",
    NULL AS "has_variant",
    'Sales Only' AS "source_type"
FROM "STD_Sales_Report" s
WHERE NOT EXISTS (
    SELECT 1
    FROM "STD_Menu_Master" m
    WHERE m."item_number" = s."item_number"
)
GROUP BY
    s."item_number",
    s."item_name";
