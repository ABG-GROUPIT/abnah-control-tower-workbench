-- Query Table: FACT_Event_Sales_Impact
-- Purpose: Join manual event windows to sales and calculate directional event lift.
-- Sources: DIM_Event, FACT_Sales
-- Join keys: sales_date between event dates, plus outlet/category/item text scope.
-- Needs Zoho syntax validation: LIKE with CONCAT and DATEADD may need local adjustment.
-- Fallback: remove baseline_sales and sales_lift_pct columns first, then calculate them as formulas or a second query table.

SELECT
    e."event_id",
    e."event_name",
    e."event_type",
    e."start_date",
    e."end_date",
    e."outlet_scope",
    e."affected_outlets",
    e."affected_category",
    e."affected_items",
    e."confidence_level",
    e."expected_impact_pct",
    s."sales_date",
    s."outlet_code",
    s."outlet_name",
    s."market_area",
    s."item_number",
    s."item_name",
    s."super_category",
    s."category",
    SUM(s."qty") AS "event_day_qty",
    SUM(s."net_sale") AS "event_day_sales",
    (
        SELECT AVG(bd."daily_sales")
        FROM (
            SELECT
                b."sales_date",
                SUM(b."net_sale") AS "daily_sales"
            FROM "FACT_Sales" b
            WHERE b."outlet_name" = s."outlet_name"
              AND b."outlet_code" = s."outlet_code"
              AND b."item_number" = s."item_number"
              AND b."sales_date" >= DATEADD(day, -7, e."start_date")
              AND b."sales_date" < e."start_date"
            GROUP BY b."sales_date"
        ) bd
    ) AS "baseline_sales",
    CASE
        WHEN (
            SELECT AVG(bd2."daily_sales")
            FROM (
                SELECT
                    b2."sales_date",
                    SUM(b2."net_sale") AS "daily_sales"
                FROM "FACT_Sales" b2
                WHERE b2."outlet_name" = s."outlet_name"
                  AND b2."outlet_code" = s."outlet_code"
                  AND b2."item_number" = s."item_number"
                  AND b2."sales_date" >= DATEADD(day, -7, e."start_date")
                  AND b2."sales_date" < e."start_date"
                GROUP BY b2."sales_date"
            ) bd2
        ) > 0
        THEN (
            SUM(s."net_sale") - (
                SELECT AVG(bd3."daily_sales")
                FROM (
                    SELECT
                        b3."sales_date",
                        SUM(b3."net_sale") AS "daily_sales"
                    FROM "FACT_Sales" b3
                    WHERE b3."outlet_name" = s."outlet_name"
                      AND b3."outlet_code" = s."outlet_code"
                      AND b3."item_number" = s."item_number"
                      AND b3."sales_date" >= DATEADD(day, -7, e."start_date")
                      AND b3."sales_date" < e."start_date"
                    GROUP BY b3."sales_date"
                ) bd3
            )
        ) / (
            SELECT AVG(bd4."daily_sales")
            FROM (
                SELECT
                    b4."sales_date",
                    SUM(b4."net_sale") AS "daily_sales"
                FROM "FACT_Sales" b4
                WHERE b4."outlet_name" = s."outlet_name"
                  AND b4."outlet_code" = s."outlet_code"
                  AND b4."item_number" = s."item_number"
                  AND b4."sales_date" >= DATEADD(day, -7, e."start_date")
                  AND b4."sales_date" < e."start_date"
                GROUP BY b4."sales_date"
            ) bd4
        ) * 100
        ELSE NULL
    END AS "sales_lift_pct"
FROM "DIM_Event" e
INNER JOIN "FACT_Sales" s
    ON s."sales_date" BETWEEN e."start_date" AND e."end_date"
   AND (
        e."outlet_scope" = 'All outlets'
        OR e."affected_outlets" LIKE CONCAT('%', s."outlet_name", '%')
   )
   AND (
        e."affected_category" IS NULL
        OR e."affected_category" = ''
        OR e."affected_category" LIKE CONCAT('%', s."category", '%')
        OR e."affected_category" LIKE CONCAT('%', s."super_category", '%')
   )
   AND (
        e."affected_items" IS NULL
        OR e."affected_items" = ''
        OR e."affected_items" LIKE CONCAT('%', s."item_name", '%')
   )
GROUP BY
    e."event_id",
    e."event_name",
    e."event_type",
    e."start_date",
    e."end_date",
    e."outlet_scope",
    e."affected_outlets",
    e."affected_category",
    e."affected_items",
    e."confidence_level",
    e."expected_impact_pct",
    s."sales_date",
    s."outlet_code",
    s."outlet_name",
    s."market_area",
    s."item_number",
    s."item_name",
    s."super_category",
    s."category";
