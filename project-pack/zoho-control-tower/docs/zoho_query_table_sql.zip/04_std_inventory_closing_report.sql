-- Query Table: STD_Inventory_Closing_Report
-- Purpose: Union outlet-specific RAW inventory feeds into standardized daily outlet-item closing inventory rows.
-- Sources: RAW_Inventory_Closing_Report_OUT001, RAW_Inventory_Closing_Report_OUT002, RAW_Inventory_Closing_Report_OUT003
-- Caveat: Low stock logic in later tables is heuristic, not prediction.

SELECT
    src."row_id" AS "inventory_row_id",
    src."deployment" AS "outlet_name",
    CASE
        WHEN src."deployment" = 'ABNAH Cafe Connaught Place' THEN 'OUT001'
        WHEN src."deployment" = 'ABNAH Cafe Hauz Khas' THEN 'OUT002'
        WHEN src."deployment" = 'ABNAH Cafe Saket Premium' THEN 'OUT003'
        ELSE NULL
    END AS "outlet_code",
    CASE
        WHEN src."deployment" = 'ABNAH Cafe Connaught Place' THEN 'Connaught Place'
        WHEN src."deployment" = 'ABNAH Cafe Hauz Khas' THEN 'Hauz Khas'
        WHEN src."deployment" = 'ABNAH Cafe Saket Premium' THEN 'Saket'
        ELSE NULL
    END AS "market_area",
    CAST(src."date" AS DATE) AS "inventory_date",
    CAST(src."generation_date" AS DATE) AS "generation_date",
    src."generation_time",
    src."item_code",
    src."item_name",
    src."super_category_code",
    src."super_category_name",
    src."category_code",
    src."category_name",
    src."unit_name",
    CAST(src."average_price" AS DECIMAL(14,2)) AS "average_price",
    CAST(src."store_stock_qty" AS DECIMAL(14,4)) AS "store_stock_qty",
    CAST(src."total_qty" AS DECIMAL(14,4)) AS "total_qty",
    CAST(src."total_amt" AS DECIMAL(14,2)) AS "total_amt"
FROM (
    SELECT * FROM "RAW_Inventory_Closing_Report_OUT001"
    UNION ALL
    SELECT * FROM "RAW_Inventory_Closing_Report_OUT002"
    UNION ALL
    SELECT * FROM "RAW_Inventory_Closing_Report_OUT003"
) src;
