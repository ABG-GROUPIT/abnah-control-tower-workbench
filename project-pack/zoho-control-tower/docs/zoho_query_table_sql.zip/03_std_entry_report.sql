-- Query Table: STD_Entry_Report
-- Purpose: Union outlet-specific RAW entry feeds into standardized receipt/GRN-style rows.
-- Sources: RAW_Entry_Report_OUT001, RAW_Entry_Report_OUT002, RAW_Entry_Report_OUT003
-- Join keys downstream: outlet_name, vendor_name, item_code, receipt_date.
-- Caveat: Entry rows do not carry po_number, so PO matching is approximate.

SELECT
    src."row_id" AS "entry_row_id",
    src."deployment_name" AS "outlet_name",
    CASE
        WHEN src."deployment_name" = 'ABNAH Cafe Connaught Place' THEN 'OUT001'
        WHEN src."deployment_name" = 'ABNAH Cafe Hauz Khas' THEN 'OUT002'
        WHEN src."deployment_name" = 'ABNAH Cafe Saket Premium' THEN 'OUT003'
        ELSE NULL
    END AS "outlet_code",
    CASE
        WHEN src."deployment_name" = 'ABNAH Cafe Connaught Place' THEN 'Connaught Place'
        WHEN src."deployment_name" = 'ABNAH Cafe Hauz Khas' THEN 'Hauz Khas'
        WHEN src."deployment_name" = 'ABNAH Cafe Saket Premium' THEN 'Saket'
        ELSE NULL
    END AS "market_area",
    src."store_kitchen_name",
    src."user_name",
    src."vendor_name",
    CAST(src."date" AS DATE) AS "receipt_date",
    src."transaction_number",
    src."invoice_number",
    CAST(src."invoice_date" AS DATE) AS "invoice_date",
    src."item_code",
    src."item_name",
    src."category_name",
    src."super_category_name",
    CAST(src."quantity" AS DECIMAL(14,4)) AS "received_qty",
    src."unit",
    CAST(src."mrp" AS DECIMAL(14,2)) AS "mrp",
    CAST(src."unit_price" AS DECIMAL(14,2)) AS "unit_price",
    CAST(src."amount" AS DECIMAL(14,2)) AS "amount",
    CAST(src."discount" AS DECIMAL(14,2)) AS "discount",
    CAST(src."gst_igst_rate" AS DECIMAL(8,2)) AS "gst_igst_rate",
    CAST(src."gst_igst_value" AS DECIMAL(14,2)) AS "gst_igst_value",
    CAST(src."total_tax" AS DECIMAL(14,2)) AS "total_tax",
    CAST(src."item_charges_amount" AS DECIMAL(14,2)) AS "item_charges_amount",
    CAST(src."entry_total" AS DECIMAL(14,2)) AS "entry_total",
    CAST(src."return_quantity" AS DECIMAL(14,4)) AS "return_qty",
    CAST(src."return_amount" AS DECIMAL(14,2)) AS "return_amount",
    CAST(src."grand_total" AS DECIMAL(14,2)) AS "grand_total"
FROM (
    SELECT * FROM "RAW_Entry_Report_OUT001"
    UNION ALL
    SELECT * FROM "RAW_Entry_Report_OUT002"
    UNION ALL
    SELECT * FROM "RAW_Entry_Report_OUT003"
) src;
