-- Query Table: FACT_Entry_Receipt
-- Purpose: Receipt/GRN line fact with vendor and ingredient context.
-- Sources: STD_Entry_Report, DIM_Vendor, DIM_Ingredient
-- Join keys: vendor_name, item_code/item_name.

SELECT
    e."entry_row_id",
    e."receipt_date",
    e."invoice_date",
    e."transaction_number",
    e."invoice_number",
    e."outlet_code",
    e."outlet_name",
    e."market_area",
    e."store_kitchen_name",
    e."user_name",
    e."vendor_name",
    v."vendor_code",
    e."item_code",
    e."item_name",
    e."category_name",
    e."super_category_name",
    e."received_qty",
    e."unit",
    e."unit_price",
    e."amount",
    e."discount",
    e."gst_igst_rate",
    e."gst_igst_value",
    e."total_tax",
    e."item_charges_amount",
    e."entry_total",
    e."return_qty",
    e."return_amount",
    e."grand_total",
    CASE
        WHEN e."received_qty" <> 0 THEN e."grand_total" / e."received_qty"
        ELSE NULL
    END AS "realized_receipt_unit_cost"
FROM "STD_Entry_Report" e
LEFT JOIN "DIM_Vendor" v
    ON v."vendor_name" = e."vendor_name"
LEFT JOIN "DIM_Ingredient" i
    ON i."ingredient_code" = e."item_code";
