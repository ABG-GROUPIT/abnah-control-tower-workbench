-- Query Table: FACT_Sales
-- Purpose: Sales fact enriched with menu metadata and holiday context.
-- Sources: STD_Sales_Report, DIM_Menu_Item, STD_Holiday_Calendar
-- Join keys: item_number, sales_date.
-- Caveat: Sales grain is daily outlet-item aggregate, not individual bills.

SELECT
    s."sales_row_id",
    s."sales_date",
    s."outlet_code",
    s."outlet_name",
    s."market_area",
    s."item_number",
    s."item_name",
    COALESCE(m."super_category_name", s."super_category") AS "super_category",
    COALESCE(m."category_name", s."category") AS "category",
    m."menu_rate",
    s."qty",
    s."net_sale",
    s."net_sale_per_qty",
    h."holiday_name",
    h."holiday_type",
    h."impact_direction" AS "holiday_impact_direction"
FROM "STD_Sales_Report" s
LEFT JOIN "DIM_Menu_Item" m
    ON m."item_number" = s."item_number"
LEFT JOIN "STD_Holiday_Calendar" h
    ON h."calendar_date" = s."sales_date";
