-- Query Table: FACT_Vendor_Spend
-- Purpose: Vendor/date/outlet spend fact combining PO value and receipt value.
-- Sources: FACT_Purchase_Order, FACT_Entry_Receipt
-- Supplemental file: requested layer list includes FACT_Vendor_Spend, but the requested numbered file list omitted it.

SELECT
    x."activity_date",
    x."outlet_code",
    x."outlet_name",
    x."market_area",
    x."vendor_name",
    SUM(x."ordered_value") AS "ordered_value",
    SUM(x."received_value") AS "received_value",
    SUM(x."po_line_count") AS "po_line_count",
    SUM(x."receipt_line_count") AS "receipt_line_count"
FROM (
    SELECT
        po."po_date" AS "activity_date",
        po."outlet_code",
        po."outlet_name",
        po."market_area",
        po."vendor_name",
        SUM(po."total_item_cost") AS "ordered_value",
        0 AS "received_value",
        COUNT(*) AS "po_line_count",
        0 AS "receipt_line_count"
    FROM "FACT_Purchase_Order" po
    GROUP BY
        po."po_date",
        po."outlet_code",
        po."outlet_name",
        po."market_area",
        po."vendor_name"

    UNION ALL

    SELECT
        er."receipt_date" AS "activity_date",
        er."outlet_code",
        er."outlet_name",
        er."market_area",
        er."vendor_name",
        0 AS "ordered_value",
        SUM(er."grand_total") AS "received_value",
        0 AS "po_line_count",
        COUNT(*) AS "receipt_line_count"
    FROM "FACT_Entry_Receipt" er
    GROUP BY
        er."receipt_date",
        er."outlet_code",
        er."outlet_name",
        er."market_area",
        er."vendor_name"
) x
GROUP BY
    x."activity_date",
    x."outlet_code",
    x."outlet_name",
    x."market_area",
    x."vendor_name";
