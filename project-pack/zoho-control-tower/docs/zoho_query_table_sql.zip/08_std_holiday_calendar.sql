-- Query Table: STD_Holiday_Calendar
-- Purpose: Standardize configured Indian holiday/calendar rows.
-- Source: RAW_Indian_Calendar_Holidays
-- Caveat: Synthetic calendar rows should be verified before production use.

SELECT
    h."row_id" AS "holiday_row_id",
    CAST(h."calendar_date" AS DATE) AS "calendar_date",
    h."holiday_name",
    h."holiday_type",
    h."region",
    h."is_public_holiday",
    h."is_bank_holiday",
    h."expected_business_impact",
    h."impact_direction",
    h."notes"
FROM "RAW_Indian_Calendar_Holidays" h;
