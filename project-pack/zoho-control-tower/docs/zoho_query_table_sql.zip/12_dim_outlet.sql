-- Query Table: DIM_Outlet
-- Purpose: Reusable outlet dimension from all operational reports.
-- Sources: STD_Sales_Report, STD_Purchase_Report, STD_Entry_Report, STD_Inventory_Closing_Report
-- Caveat: There is no separate outlet master feed; outlet_name is the practical key.

SELECT DISTINCT
    o."outlet_code" AS "outlet_key",
    o."outlet_code",
    o."outlet_name",
    o."market_area"
FROM (
    SELECT s."outlet_code", s."outlet_name", s."market_area" FROM "STD_Sales_Report" s
    UNION
    SELECT p."outlet_code", p."outlet_name", p."market_area" FROM "STD_Purchase_Report" p
    UNION
    SELECT e."outlet_code", e."outlet_name", e."market_area" FROM "STD_Entry_Report" e
    UNION
    SELECT inv."outlet_code", inv."outlet_name", inv."market_area" FROM "STD_Inventory_Closing_Report" inv
) o
WHERE o."outlet_name" IS NOT NULL
  AND TRIM(o."outlet_name") <> '';
