-- Query Table: STD_Purchase_Report
-- Purpose: Union outlet-specific RAW purchase feeds into standardized purchase order line rows.
-- Sources: RAW_Purchase_Report_OUT001, RAW_Purchase_Report_OUT002, RAW_Purchase_Report_OUT003
-- Join keys downstream: po_number, outlet_name, vendor_name, item_code, po_date.
-- Needs Zoho syntax validation: CAST behavior may vary if Zoho already imports dates/numbers correctly.

SELECT
    src."row_id" AS "purchase_row_id",
    src."deployment" AS "outlet_name",
    CASE
        WHEN src."deployment" = 'ABNAH Cafe Connaught Place' THEN 'OUT001'
        WHEN src."deployment" = 'ABNAH Cafe Hauz Khas' THEN 'OUT002'
        WHEN src."deployment" = 'ABNAH Cafe Saket Premium' THEN 'OUT003'
        ELSE NULL
    END AS "outlet_code",
    CASE
        WHEN src."deployment" = 'ABNAH Cafe Connaught Place' THEN 'Connaught Place'
        WHEN src."deployment" = 'ABNAH Cafe Hauz Khas' THEN 'Hauz Khas'
        WHEN src."deployment" = 'ABNAH Cafe Saket Premium' THEN 'Saket'
        ELSE NULL
    END AS "market_area",
    src."store_name",
    src."vendor_name",
    src."po_number",
    CAST(src."po_date" AS DATE) AS "po_date",
    CAST(src."expected_delivery" AS DATE) AS "expected_delivery_date",
    src."po_status",
    src."item_code",
    src."item_name",
    src."category_name",
    src."super_category_name",
    CAST(src."total_processed_qty" AS DECIMAL(14,4)) AS "processed_qty",
    CAST(src."remaining_balance_qty" AS DECIMAL(14,4)) AS "remaining_qty",
    CAST(src."quantity" AS DECIMAL(14,4)) AS "ordered_qty",
    src."unit",
    CAST(src."unit_price" AS DECIMAL(14,2)) AS "unit_price",
    CAST(src."subtotal" AS DECIMAL(14,2)) AS "subtotal",
    CAST(src."tax" AS DECIMAL(14,2)) AS "tax",
    CAST(src."total_item_cost" AS DECIMAL(14,2)) AS "total_item_cost",
    CASE
        WHEN src."po_status" = 'Closed' THEN 0
        ELSE 1
    END AS "is_open_or_partial"
FROM (
    SELECT * FROM "RAW_Purchase_Report_OUT001"
    UNION ALL
    SELECT * FROM "RAW_Purchase_Report_OUT002"
    UNION ALL
    SELECT * FROM "RAW_Purchase_Report_OUT003"
) src;
