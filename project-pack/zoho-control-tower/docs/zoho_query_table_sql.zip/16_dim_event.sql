-- Query Table: DIM_Event
-- Purpose: Reusable manual event dimension.
-- Source: STD_Manual_Events
-- Join keys: event_id, start_date/end_date, affected scope text.

SELECT
    e."event_id" AS "event_key",
    e."event_id",
    e."event_name",
    e."event_type",
    e."start_date",
    e."end_date",
    e."outlet_scope",
    e."affected_outlets",
    e."affected_category",
    e."affected_items",
    e."expected_impact_pct",
    e."impact_direction",
    e."confidence_level",
    e."event_source",
    e."admin_status",
    e."notes"
FROM "STD_Manual_Events" e;
